import socialRoutes from './social.routes.js';
import webhooksRoutes from './webhooks.routes.js';

// ----------------------------------------------------------------------------

export { socialRoutes, webhooksRoutes };
